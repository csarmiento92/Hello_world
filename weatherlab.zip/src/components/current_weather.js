import React from 'react';

const CurrentWeather = ({ currentWeather }) => <h1>Today: {currentWeather}</h1>

export default CurrentWeather;